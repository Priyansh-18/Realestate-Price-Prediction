from django.contrib.auth.hashers import make_password, check_password
from django.shortcuts import render, redirect

from model.models import Customer


# Create your views here.
def Home(request):
    return render(request, 'Home.html')


def login(request):
    if request.method == 'GET':
        return render(request, 'user_login.html')

    else:
        email = request.POST.get('email')
        password = request.POST.get('psw')
        customer = Customer.get_customer_by_email(email)
        error_message = None

        if customer:
            flag = check_password(password, customer.password)
            if flag:
                request.session['customer_id'] = customer.id
                request.session['customer_email'] = customer.email
                return redirect('home')
            else:
                error_message = 'invalid email or password'
        else:
            error_message = 'invalid email or password'
        return render(request, 'user_login.html', {'error': error_message})


def signup(request):
    if request.method == 'GET':
        return render(request, 'user_registration.html')

    else:
        first_name = request.POST.get('fname')
        last_name = request.POST.get('lname')
        phone = request.POST.get('phone')
        email = request.POST.get('email')
        password = request.POST.get('psw')

        customer = Customer(first_name=first_name,
                            last_name=last_name,
                            phone=phone,
                            email=email,
                            password=password)

        customer.password = make_password(customer.password)
        customer.save()

        return redirect('home')
